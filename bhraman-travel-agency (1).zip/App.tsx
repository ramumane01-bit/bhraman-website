import React, { useState } from 'react';
import { ViewState } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import Packages from './components/Packages';
import TripPlanner from './components/TripPlanner';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import About from './components/About';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);

  const renderView = () => {
    switch (currentView) {
      case ViewState.HOME:
        return (
          <>
            <Hero setView={setCurrentView} />
            <div className="bg-white">
                <div className="py-12 text-center">
                    <h2 className="text-2xl font-bold text-gray-800">Featured Packages</h2>
                    <p className="text-gray-500">Curated specifically for this season</p>
                </div>
                <Packages setView={setCurrentView} />
                <div className="py-12 bg-brand-50">
                     <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="lg:text-center">
                            <h2 className="text-base text-brand-600 font-semibold tracking-wide uppercase">AI Powered</h2>
                            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                                Plan your dream trip in seconds
                            </p>
                            <div className="mt-10 flex justify-center">
                                <button 
                                    onClick={() => setCurrentView(ViewState.PLANNER)}
                                    className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500"
                                >
                                    Try Smart Planner
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <Testimonials />
            </div>
          </>
        );
      case ViewState.PACKAGES:
        return <Packages setView={setCurrentView} />;
      case ViewState.PLANNER:
        return <TripPlanner setView={setCurrentView} />;
      case ViewState.CONTACT:
        return <Contact />;
      case ViewState.ABOUT:
        return <About />;
      default:
        return <Hero setView={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans">
      <Header currentView={currentView} setView={setCurrentView} />
      <main className="flex-grow">
        {renderView()}
      </main>
      <Footer setView={setCurrentView} />
    </div>
  );
};

export default App;