import React from 'react';

const About = () => {
  return (
    <div className="bg-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
            <div className="mb-10 lg:mb-0">
                <img 
                    src="https://picsum.photos/seed/team/800/600" 
                    alt="Bhraman Team" 
                    className="rounded-2xl shadow-xl w-full object-cover"
                />
            </div>
            <div>
                <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl mb-6">
                    Redefining Travel with <span className="text-brand-600">Bhraman</span>
                </h2>
                <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                    Founded in 2024, Bhraman was born from a simple belief: Travel should be seamless, personal, and inspiring. We combine cutting-edge AI technology with human expertise to curate trips that aren't just vacations, but lifelong memories.
                </p>
                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                    Whether you are seeking a luxury escape, a backpacking adventure, or a family reunion, our platform empowers you to visualize your journey before you book. We are committed to transparency, quality, and your happiness.
                </p>
                <div className="grid grid-cols-2 gap-6">
                    <div className="border-l-4 border-accent-500 pl-4">
                        <p className="text-3xl font-bold text-gray-900">500+</p>
                        <p className="text-sm text-gray-500">Destinations</p>
                    </div>
                     <div className="border-l-4 border-accent-500 pl-4">
                        <p className="text-3xl font-bold text-gray-900">10k+</p>
                        <p className="text-sm text-gray-500">Happy Travelers</p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default About;