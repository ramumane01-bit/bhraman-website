import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Loader2 } from 'lucide-react';

const Contact = () => {
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const formData = new FormData(e.currentTarget);

    try {
      const response = await fetch("https://formspree.io/f/mvgeqlyk", {
        method: "POST",
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      });

      if (response.ok) {
        setSubmitted(true);
        setTimeout(() => setSubmitted(false), 5000);
        e.currentTarget.reset();
      } else {
        alert("There was a problem sending your message. Please try again.");
      }
    } catch (error) {
      alert("There was a problem sending your message. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-brand-50 min-h-screen py-16 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-10 bg-white rounded-3xl shadow-2xl overflow-hidden">
        
        {/* Contact Info Side */}
        <div className="bg-brand-600 p-10 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 -mr-10 -mt-10 w-40 h-40 bg-white opacity-10 rounded-full"></div>
          <div className="absolute bottom-0 left-0 -ml-10 -mb-10 w-40 h-40 bg-white opacity-10 rounded-full"></div>
          
          <div>
            <h2 className="text-4xl font-bold mb-6">Get in Touch</h2>
            <p className="text-brand-100 mb-10 text-lg">
              Ready to start your adventure? Contact us for bookings, custom packages, or any travel queries.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center">
                <div className="bg-white/20 p-3 rounded-lg mr-4">
                    <Phone className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-brand-200 uppercase tracking-wider font-semibold">Phone</p>
                  <p className="text-lg font-medium">+91 98765 43210</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="bg-white/20 p-3 rounded-lg mr-4">
                    <Mail className="w-6 h-6" />
                </div>
                <div>
                   <p className="text-xs text-brand-200 uppercase tracking-wider font-semibold">Email</p>
                   <p className="text-lg font-medium">bookings@bhraman.com</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="bg-white/20 p-3 rounded-lg mr-4">
                    <MapPin className="w-6 h-6" />
                </div>
                <div>
                   <p className="text-xs text-brand-200 uppercase tracking-wider font-semibold">Office</p>
                   <p className="text-lg font-medium">Sector 18, Noida, India</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <p className="text-sm text-brand-200">
              Bhraman Travel Agency © 2024. <br/> All rights reserved.
            </p>
          </div>
        </div>

        {/* Form Side */}
        <div className="p-10">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Send us a Message</h2>
          
          {submitted ? (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <Send className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Message Sent!</h3>
              <p className="text-gray-600">We'll get back to you within 24 hours.</p>
              <button onClick={() => setSubmitted(false)} className="mt-6 text-brand-600 font-semibold hover:text-brand-800">
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                  <input type="text" name="firstName" required className="w-full px-4 py-3 rounded-lg bg-gray-50 border-transparent focus:border-brand-500 focus:bg-white focus:ring-0 transition" placeholder="John" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                  <input type="text" name="lastName" required className="w-full px-4 py-3 rounded-lg bg-gray-50 border-transparent focus:border-brand-500 focus:bg-white focus:ring-0 transition" placeholder="Doe" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input type="email" name="email" required className="w-full px-4 py-3 rounded-lg bg-gray-50 border-transparent focus:border-brand-500 focus:bg-white focus:ring-0 transition" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Mobile Number</label>
                  <input type="tel" name="mobile" required className="w-full px-4 py-3 rounded-lg bg-gray-50 border-transparent focus:border-brand-500 focus:bg-white focus:ring-0 transition" placeholder="+91 98765 43210" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message / Query</label>
                <textarea rows={4} name="message" required className="w-full px-4 py-3 rounded-lg bg-gray-50 border-transparent focus:border-brand-500 focus:bg-white focus:ring-0 transition" placeholder="I'm interested in the Bali package..."></textarea>
              </div>

              <button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-4 rounded-lg shadow-lg transition duration-300 transform hover:-translate-y-1 flex items-center justify-center disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : 'Send Message'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default Contact;