import React from 'react';
import { ViewState } from '../types';
import { Facebook, Twitter, Instagram, Plane } from 'lucide-react';

interface FooterProps {
    setView: (view: ViewState) => void;
}

const Footer: React.FC<FooterProps> = ({ setView }) => {
  return (
    <footer className="bg-gray-900 text-white border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center mb-4">
                <Plane className="text-brand-500 w-6 h-6 mr-2" />
                <span className="text-xl font-bold">Bhraman</span>
            </div>
            <p className="text-gray-400 text-sm">
              Your trusted partner for exploring the world. Making travel planning easy, affordable, and memorable.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase mb-4">Company</h3>
            <ul className="space-y-3">
              <li><button onClick={() => setView(ViewState.ABOUT)} className="text-gray-400 hover:text-white text-sm transition">About Us</button></li>
              <li><button onClick={() => setView(ViewState.CONTACT)} className="text-gray-400 hover:text-white text-sm transition">Careers</button></li>
              <li><button onClick={() => setView(ViewState.CONTACT)} className="text-gray-400 hover:text-white text-sm transition">Privacy Policy</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase mb-4">Destinations</h3>
            <ul className="space-y-3">
              <li><button onClick={() => setView(ViewState.PACKAGES)} className="text-gray-400 hover:text-white text-sm transition">Maldives</button></li>
              <li><button onClick={() => setView(ViewState.PACKAGES)} className="text-gray-400 hover:text-white text-sm transition">Dubai</button></li>
              <li><button onClick={() => setView(ViewState.PACKAGES)} className="text-gray-400 hover:text-white text-sm transition">Europe</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Instagram className="w-6 h-6" />
              </a>
            </div>
          </div>

        </div>
        <div className="mt-12 border-t border-gray-800 pt-8 flex justify-between items-center">
            <p className="text-sm text-gray-500">© 2024 Bhraman. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;