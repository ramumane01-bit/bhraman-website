import React, { useState } from 'react';
import { Package, ViewState } from '../types';
import { Clock, Users, Star, CheckCircle, Globe, Map } from 'lucide-react';

interface PackagesProps {
  setView: (view: ViewState) => void;
}

const Packages: React.FC<PackagesProps> = ({ setView }) => {
  const [activeTab, setActiveTab] = useState<'International' | 'Domestic'>('International');

  const internationalPackages: Package[] = [
    {
      id: '1',
      title: 'Bali Bliss Getaway',
      destination: 'Bali, Indonesia',
      duration: '5 Days / 4 Nights',
      price: 45000,
      image: 'https://picsum.photos/seed/bali/800/600',
      rating: 4.8,
      features: ['Flight Included', '4 Star Hotel', 'Island Tour', 'Daily Breakfast']
    },
    {
      id: '2',
      title: 'Dubai Desert Safari',
      destination: 'Dubai, UAE',
      duration: '6 Days / 5 Nights',
      price: 65000,
      image: 'https://picsum.photos/seed/dubai/800/600',
      rating: 4.9,
      features: ['Burj Khalifa Ticket', 'Desert BBQ', 'City Tour', 'Visa Assistance']
    },
    {
      id: '3',
      title: 'Amazing Thailand',
      destination: 'Bangkok & Pattaya',
      duration: '5 Days / 4 Nights',
      price: 35000,
      image: 'https://picsum.photos/seed/thailand/800/600',
      rating: 4.7,
      features: ['Coral Island', 'Alcazar Show', 'Airport Transfer', 'All Meals']
    },
    {
      id: '4',
      title: 'European Dream',
      destination: 'Paris & Zurich',
      duration: '8 Days / 7 Nights',
      price: 145000,
      image: 'https://picsum.photos/seed/paris/800/600',
      rating: 5.0,
      features: ['Swiss Pass', 'Eiffel Tower', 'Seine Cruise', 'Centrally Located Hotels']
    },
  ];

  const domesticPackages: Package[] = [
    {
      id: 'd1',
      title: 'Magical Kerala',
      destination: 'Munnar & Alleppey',
      duration: '5 Days / 4 Nights',
      price: 24999,
      image: 'https://picsum.photos/seed/kerala/800/600',
      rating: 4.9,
      features: ['Houseboat Stay', 'Tea Gardens', 'Airport Pickup', 'All Meals']
    },
    {
      id: 'd2',
      title: 'Royal Rajasthan',
      destination: 'Jaipur & Udaipur',
      duration: '6 Days / 5 Nights',
      price: 32500,
      image: 'https://picsum.photos/seed/jaipur/800/600',
      rating: 4.8,
      features: ['Heritage Hotels', 'City Palace Tour', 'Jeep Safari', 'Cultural Show']
    },
    {
      id: 'd3',
      title: 'Goa Beach Vibes',
      destination: 'North & South Goa',
      duration: '4 Days / 3 Nights',
      price: 18500,
      image: 'https://picsum.photos/seed/goa/800/600',
      rating: 4.7,
      features: ['Beach Resort', 'Scooter Rental', 'Cruise Dinner', 'Water Sports']
    },
    {
      id: 'd4',
      title: 'Heavenly Kashmir',
      destination: 'Srinagar & Gulmarg',
      duration: '6 Days / 5 Nights',
      price: 38000,
      image: 'https://picsum.photos/seed/kashmir/800/600',
      rating: 5.0,
      features: ['Shikara Ride', 'Gondola Ride', 'Houseboat Stay', 'Bonfire Night']
    }
  ];

  const displayedPackages = activeTab === 'International' ? internationalPackages : domesticPackages;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="bg-gray-50 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Explore Our Packages
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Handpicked domestic and international experiences at unbeatable prices.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-12">
          <div className="bg-white p-1.5 rounded-full shadow-md inline-flex relative z-0">
            <button
              onClick={() => setActiveTab('International')}
              className={`flex items-center px-8 py-3 rounded-full text-sm font-bold transition-all duration-300 ${
                activeTab === 'International'
                  ? 'bg-brand-600 text-white shadow-md transform scale-105'
                  : 'text-gray-500 hover:text-brand-600 hover:bg-gray-50'
              }`}
            >
              <Globe className="w-4 h-4 mr-2" />
              International
            </button>
            <button
              onClick={() => setActiveTab('Domestic')}
              className={`flex items-center px-8 py-3 rounded-full text-sm font-bold transition-all duration-300 ${
                activeTab === 'Domestic'
                  ? 'bg-brand-600 text-white shadow-md transform scale-105'
                  : 'text-gray-500 hover:text-brand-600 hover:bg-gray-50'
              }`}
            >
              <Map className="w-4 h-4 mr-2" />
              Domestic
            </button>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-2 xl:grid-cols-2">
          {displayedPackages.map((pkg) => (
            <div key={pkg.id} className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col md:flex-row hover:shadow-xl transition-shadow duration-300 animate-fade-in-up">
              <div className="md:w-2/5 relative group overflow-hidden">
                <img
                  className="h-64 w-full object-cover md:h-full transform transition-transform duration-500 group-hover:scale-110"
                  src={pkg.image}
                  alt={pkg.title}
                />
                <div className="absolute top-4 left-4 bg-accent-500 text-white px-3 py-1 rounded-full text-sm font-bold shadow-md z-10">
                  Best Seller
                </div>
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-opacity duration-300"></div>
              </div>
              <div className="p-6 md:w-3/5 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-2xl font-bold text-gray-900 group-hover:text-brand-600 transition-colors">{pkg.title}</h3>
                        <p className="text-sm text-gray-500 flex items-center mt-1">
                            <span className="mr-2">{pkg.destination}</span>
                        </p>
                    </div>
                    <div className="flex items-center bg-green-100 px-2 py-1 rounded">
                        <Star className="w-4 h-4 text-green-600 fill-current" />
                        <span className="ml-1 text-sm font-bold text-green-700">{pkg.rating}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex items-center text-gray-600 text-sm font-medium">
                    <Clock className="w-4 h-4 mr-2 text-brand-500" />
                    {pkg.duration}
                  </div>

                  <div className="mt-4 space-y-2">
                    {pkg.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center text-sm text-gray-600">
                            <CheckCircle className="w-4 h-4 text-brand-500 mr-2 flex-shrink-0" />
                            {feature}
                        </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 flex items-center justify-between border-t pt-4">
                  <div>
                    <p className="text-sm text-gray-500">Starting from</p>
                    <p className="text-2xl font-bold text-brand-700">{formatCurrency(pkg.price)}</p>
                    <p className="text-xs text-gray-400">per person</p>
                  </div>
                  <button 
                    onClick={() => setView(ViewState.CONTACT)}
                    className="bg-brand-600 hover:bg-brand-700 text-white px-6 py-2.5 rounded-lg font-semibold transition-all transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
                  >
                    Book Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Packages;