import React from 'react';

const Testimonials = () => {
  const reviews = [
    {
      id: 1,
      name: 'Priya Sharma',
      role: 'Family Traveler',
      text: 'Bhraman organized our Dubai trip perfectly. The AI planner gave us a great starting point, and their team customized it to fit our budget. Highly recommended!',
      image: 'https://picsum.photos/seed/user1/100/100'
    },
    {
      id: 2,
      name: 'Rahul Verma',
      role: 'Adventure Enthusiast',
      text: 'I used the custom planner for a solo trip to Bali. The hotel recommendations were spot on and the itinerary flow was logical. Great experience.',
      image: 'https://picsum.photos/seed/user2/100/100'
    },
    {
      id: 3,
      name: 'Anita Desai',
      role: 'Honeymooner',
      text: 'Our Europe trip was magical. Bhraman handled all the visa hassles and bookings. The prices were very transparent.',
      image: 'https://picsum.photos/seed/user3/100/100'
    }
  ];

  return (
    <div className="bg-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-extrabold text-gray-900">What Our Travelers Say</h2>
          <div className="w-24 h-1 bg-brand-500 mx-auto mt-4 rounded"></div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review) => (
            <div key={review.id} className="bg-gray-50 p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow relative">
               <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
                   <img 
                    src={review.image} 
                    alt={review.name}
                    className="w-12 h-12 rounded-full border-4 border-white shadow-sm"
                   />
               </div>
               <div className="mt-6 text-center">
                    <p className="text-gray-600 italic mb-4">"{review.text}"</p>
                    <h4 className="font-bold text-gray-900">{review.name}</h4>
                    <p className="text-sm text-brand-600">{review.role}</p>
               </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Testimonials;