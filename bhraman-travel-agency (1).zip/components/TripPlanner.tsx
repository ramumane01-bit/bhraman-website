import React, { useState } from 'react';
import { TripSearchParams, GeneratedItinerary, ViewState } from '../types';
import { generateTripItinerary } from '../services/geminiService';
import { Calendar, Map, Users, Clock, Loader2, Info, Check, ArrowRight, Bed, Coffee, Phone } from 'lucide-react';

interface TripPlannerProps {
  setView: (view: ViewState) => void;
}

const TripPlanner: React.FC<TripPlannerProps> = ({ setView }) => {
  const [formData, setFormData] = useState<TripSearchParams>({
    destination: '',
    startDate: '',
    duration: 5,
    travelers: 2,
    mobileNumber: '',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<GeneratedItinerary | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'duration' || name === 'travelers' ? parseInt(value) : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setResult(null);

    // Send data to Formspree in the background (Lead Generation)
    const formSpreeData = new FormData();
    formSpreeData.append('destination', formData.destination);
    formSpreeData.append('startDate', formData.startDate);
    formSpreeData.append('duration', formData.duration.toString());
    formSpreeData.append('travelers', formData.travelers.toString());
    formSpreeData.append('mobileNumber', formData.mobileNumber || '');
    formSpreeData.append('formType', 'Trip Planner AI Request');

    fetch("https://formspree.io/f/mvgeqlyk", {
      method: "POST",
      body: formSpreeData,
      headers: { 'Accept': 'application/json' }
    }).catch(err => console.error("Error submitting lead to Formspree:", err));

    try {
      const data = await generateTripItinerary(formData);
      setResult(data);
    } catch (err) {
      setError("Failed to generate itinerary. Please try again. Make sure you have a valid API Key.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-10">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            AI-Powered Smart Planner
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Tell us where and when, and we'll craft the perfect itinerary for you instantly.
          </p>
        </div>

        {/* Input Form */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-10">
          <div className="p-8 bg-brand-600 text-white">
            <h3 className="text-xl font-semibold flex items-center">
              <Map className="mr-2" /> Plan Your Journey
            </h3>
          </div>
          <form onSubmit={handleSubmit} className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="col-span-1 md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Destination</label>
              <div className="relative">
                 <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Map className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  name="destination"
                  required
                  placeholder="e.g., Paris, Tokyo, Maldives"
                  className="pl-10 block w-full border-gray-300 rounded-lg border p-3 focus:ring-brand-500 focus:border-brand-500 shadow-sm"
                  value={formData.destination}
                  onChange={handleInputChange}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mobile Number</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="tel"
                  name="mobileNumber"
                  placeholder="+91 98765 43210"
                  required
                  className="pl-10 block w-full border-gray-300 rounded-lg border p-3 focus:ring-brand-500 focus:border-brand-500 shadow-sm"
                  value={formData.mobileNumber}
                  onChange={handleInputChange}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="date"
                  name="startDate"
                  required
                  className="pl-10 block w-full border-gray-300 rounded-lg border p-3 focus:ring-brand-500 focus:border-brand-500 shadow-sm"
                  value={formData.startDate}
                  onChange={handleInputChange}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Duration (Days)</label>
              <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Clock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                      type="number"
                      name="duration"
                      min="1"
                      max="30"
                      required
                      className="pl-10 block w-full border-gray-300 rounded-lg border p-3 focus:ring-brand-500 focus:border-brand-500 shadow-sm"
                      value={formData.duration}
                      onChange={handleInputChange}
                  />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Travelers</label>
              <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Users className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                      type="number"
                      name="travelers"
                      min="1"
                      max="20"
                      required
                      className="pl-10 block w-full border-gray-300 rounded-lg border p-3 focus:ring-brand-500 focus:border-brand-500 shadow-sm"
                      value={formData.travelers}
                      onChange={handleInputChange}
                  />
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 pt-4">
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-accent-500 hover:bg-accent-600 text-white font-bold py-4 px-6 rounded-lg shadow-lg transform transition hover:scale-[1.01] flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="animate-spin mr-2" /> Generating Your Dream Trip...
                  </>
                ) : (
                  'Create My Itinerary'
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-8 rounded-md">
            <div className="flex">
              <div className="flex-shrink-0">
                <Info className="h-5 w-5 text-red-500" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="animate-fade-in-up space-y-8">
            
            {/* Summary Card */}
            <div className="bg-white rounded-2xl shadow-lg p-8 border-t-8 border-brand-500">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Trip Summary</h3>
                <p className="text-gray-600 leading-relaxed text-lg">{result.summary}</p>
                <div className="mt-6 flex flex-wrap gap-4">
                    <span className="bg-brand-100 text-brand-800 text-sm font-semibold px-4 py-2 rounded-full flex items-center">
                        <Map className="w-4 h-4 mr-2"/> {result.destination}
                    </span>
                    <span className="bg-brand-100 text-brand-800 text-sm font-semibold px-4 py-2 rounded-full flex items-center">
                         <Clock className="w-4 h-4 mr-2"/> {result.duration}
                    </span>
                    <span className="bg-brand-100 text-brand-800 text-sm font-semibold px-4 py-2 rounded-full flex items-center">
                        <Users className="w-4 h-4 mr-2"/> {result.travelers} Guests
                    </span>
                </div>
            </div>

            {/* Itinerary Timeline */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Daily Itinerary</h3>
              <div className="border-l-2 border-brand-200 ml-4 space-y-8">
                {result.itinerary.map((day) => (
                  <div key={day.dayNumber} className="relative pl-8">
                    <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-brand-500 ring-4 ring-brand-100"></div>
                    <div className="mb-2">
                        <span className="text-sm font-bold text-brand-600 uppercase tracking-wide">Day {day.dayNumber}</span>
                        <h4 className="text-xl font-bold text-gray-900">{day.title}</h4>
                    </div>
                    <ul className="space-y-2 mt-3">
                        {day.activities.map((activity, idx) => (
                            <li key={idx} className="flex items-start text-gray-600">
                                <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-accent-400 rounded-full flex-shrink-0"></span>
                                <span>{activity}</span>
                            </li>
                        ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>

            {/* Logistics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Hotels */}
                <div className="bg-white rounded-2xl shadow-lg p-6">
                    <div className="flex items-center mb-4 text-brand-700">
                        <Bed className="w-6 h-6 mr-2" />
                        <h3 className="text-xl font-bold">Recommended Hotels</h3>
                    </div>
                    <ul className="space-y-3">
                        {result.hotelRecommendations.map((hotel, idx) => (
                            <li key={idx} className="flex items-center text-gray-700 p-3 bg-gray-50 rounded-lg">
                                <span className="w-6 h-6 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center text-xs font-bold mr-3">{idx+1}</span>
                                {hotel}
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Inclusions */}
                <div className="bg-white rounded-2xl shadow-lg p-6">
                     <div className="flex items-center mb-4 text-green-700">
                        <Coffee className="w-6 h-6 mr-2" />
                        <h3 className="text-xl font-bold">Package Inclusions</h3>
                    </div>
                    <ul className="space-y-2">
                         {result.inclusions.map((inc, idx) => (
                            <li key={idx} className="flex items-start text-gray-700">
                                <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                                <span>{inc}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

            {/* Final CTA */}
            <div className="bg-gradient-to-r from-brand-600 to-brand-800 rounded-2xl shadow-xl p-8 text-center text-white">
                <h3 className="text-2xl font-bold mb-4">Love this plan?</h3>
                <p className="mb-6 opacity-90">Send this itinerary to our agents for a custom quote with the best prices.</p>
                <button 
                    onClick={() => setView(ViewState.CONTACT)}
                    className="bg-white text-brand-700 font-bold py-3 px-8 rounded-full hover:bg-gray-100 transition shadow-md flex items-center mx-auto"
                >
                    Request Quote for this Trip <ArrowRight className="ml-2 w-5 h-5"/>
                </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TripPlanner;