import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedItinerary, TripSearchParams } from "../types";

export const generateTripItinerary = async (params: TripSearchParams): Promise<GeneratedItinerary> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing. Please set the API_KEY environment variable.");
  }

  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Create a detailed travel itinerary for a trip to ${params.destination} for ${params.duration} days for ${params.travelers} travelers starting on ${params.startDate}.
    
    Include:
    1. A brief enthusiastic summary of the trip.
    2. A day-by-day itinerary with a title and list of activities for each day.
    3. 3 specific hotel recommendations (names only, mixed 3-5 stars).
    4. A list of standard package inclusions (e.g., Breakfast, Airport Transfers, etc.).
    
    Do NOT include specific costs/prices in the output.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an expert travel agent for Bhraman Travel Agency. You create exciting, detailed, and realistic travel plans.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            destination: { type: Type.STRING },
            duration: { type: Type.STRING },
            travelers: { type: Type.NUMBER },
            summary: { type: Type.STRING },
            hotelRecommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            inclusions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            itinerary: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  activities: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ["dayNumber", "title", "activities"]
              }
            }
          },
          required: ["destination", "duration", "travelers", "summary", "hotelRecommendations", "inclusions", "itinerary"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as GeneratedItinerary;
    }
    throw new Error("No response text received from Gemini.");
  } catch (error) {
    console.error("Error generating itinerary:", error);
    throw error;
  }
};