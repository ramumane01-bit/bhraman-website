export interface Package {
  id: string;
  title: string;
  destination: string;
  duration: string;
  price: number;
  image: string;
  rating: number;
  features: string[];
}

export interface ItineraryDay {
  dayNumber: number;
  title: string;
  activities: string[];
}

export interface GeneratedItinerary {
  destination: string;
  duration: string;
  travelers: number;
  summary: string;
  hotelRecommendations: string[];
  inclusions: string[];
  itinerary: ItineraryDay[];
}

export interface TripSearchParams {
  destination: string;
  startDate: string;
  duration: number;
  travelers: number;
  mobileNumber?: string;
}

export enum ViewState {
  HOME = 'HOME',
  PACKAGES = 'PACKAGES',
  PLANNER = 'PLANNER',
  CONTACT = 'CONTACT',
  ABOUT = 'ABOUT'
}